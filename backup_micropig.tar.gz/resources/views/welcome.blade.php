<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
       <link rel="stylesheet" href="{{ asset('css/butas.css') }}">
        <title>Mini Pig serch</title>
    </head>
<body>
    <body class="antialiased">
        <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">
            @if (Route::has('login'))
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    @auth
                        <a href="{{ url('/dashboard') }}" class="text-sm text-gray-700 dark:text-gray-500 underline">飼い主マイページ
                    @else
                        <a href="{{ route('login') }}" class="login-link　text-sm text-gray-700 dark:text-gray-500 underline">・飼い主ログイン</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="login-link　ml-4 text-sm text-gray-700 dark:text-gray-500 underline">・飼い主新登録</a>
                        @endif
                    @endauth
                </div>
            @endif
    <div class="hutunohito">
       <a href="{{ route('dashboard') }}" class="btn">飼い主じゃない人はこちらから！</a>
    </div>  
    <h1>MICRO PIG SERVICE TOP PRAPER </h1>
    <hr width=400 size=3>
    <h2>🐷マイクロブタとは？</h2>
    <p class="p1">・このサイトではマイクロブタに関する情報、<br>
    マイクロブタに関するイベント、実際の飼い主さんとつながれるサービスなどを提供している。<br>
    マイクロブタに興味のある人や実際に買おうかなと思っている人にとっておすすめなＷＥＢサービスです。登録するとサービスが利用できます。
    <script src="../jss/butas.js"></script>
    <div class="pig2">
     <img src="{{ asset('css/26551396_s.jpg') }}" alt="pig2 Logo" />
    </div>
    <div class="pig3">
      <img src="{{ asset('css/26551397_s.jpg') }}" alt="pig3 Logo" />
    </div>
    <p class="p2">・マイクロブタは通常のブタと比べて体が小さく、可愛らしい姿をしています。大人の体重は通常20kg未満であるため、新世代ペットとして注目されています。マイクロブタは賢く、綺麗好きで人に懐きやすい性格を持っています。</p2>
    <div class="rect"></div>   
</body>
</html>