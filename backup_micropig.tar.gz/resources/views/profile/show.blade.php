<h1>{{ $profile->name }}</h1>
<p>{{ $profile->bio }}</p>

